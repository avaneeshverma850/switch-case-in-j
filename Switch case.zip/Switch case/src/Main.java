import java.util.Scanner;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
       /* System.out.print("Enter Your Age:");
        Scanner sc = new Scanner(System.in);
        int age = sc.nextInt();*/
       /* if (age > 56) {
            System.out.println("You are experienced");
        }
        else if(age>46){
            System.out.println("You are semi-experienced");
        }
        else if(age>36){
            System.out.println("You are semi-semi experienced");
        }
        else{
            System.out.println("You are not experienced");
        }*/
        //Switch Case
        char var='6';
        switch (var) {
            case 'r':
                System.out.println("You are going to become adult");
                break;
            case 't':
                System.out.println("You are going to join job");
                break;
            case 'a':
                System.out.println("You are going to become retire");
                break;
            default:
                System.out.println("Enjoy your life");
                break;

        }
    }
}